'''
Created on Apr 23, 2021

@author: martinyanev
'''

def test_passed():
    assert (3,4,5) == (3,4,5)