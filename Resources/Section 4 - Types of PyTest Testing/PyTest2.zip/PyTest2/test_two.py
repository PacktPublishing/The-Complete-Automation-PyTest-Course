'''
Created on Apr 23, 2021

@author: martinyanev
'''
def test_failed():
    assert (3,4,5) == (5,4,3)