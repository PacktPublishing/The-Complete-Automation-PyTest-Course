"""Test file identity."""
